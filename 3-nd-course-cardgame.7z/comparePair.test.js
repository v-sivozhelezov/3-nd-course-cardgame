/* eslint @typescript-eslint/no-var-requires: "off" */
const { it } = require('@jest/globals');
const assert = require('assert').strict;
const { comparePair } = require('/comparePair');

it('', () => {
    const choice1 = 'валет черви';
    const choice2 = 'валет черви';
    const pairsCounter = 36;
    const expected = true;

    const result = comparePair({ choice1, choice2, pairsCounter });

    assert.equal(result, expected);
});
