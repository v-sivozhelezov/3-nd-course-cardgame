import { renderPage } from './renderPage';
import { LEVELS_PAGE } from './routes';
import './style/style.css';

renderPage(LEVELS_PAGE);
