import { renderPage } from './renderPage.ts';
import { LEVELS_PAGE } from './routes.ts';
import './style/style.css';

renderPage(LEVELS_PAGE);
