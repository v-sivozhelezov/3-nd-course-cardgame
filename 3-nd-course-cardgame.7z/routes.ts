// Файл со списком страниц приложения
export const LEVELS_PAGE = 'level';
export const START_GAME_PAGE = 'start_game';
export const GAME_PAGE = 'game';
export const RESULTS_PAGE = 'results';
//
